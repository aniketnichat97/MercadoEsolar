<?php 
//product php code

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");

include 'DbConnect.php';
$httpPost = file_get_contents("php://input");
$req = json_decode($httpPost);



//loading product data

try{
    $model = new DbConnect();
    $conn = $model->getConnection();

    //insert product
    $query = "insert into tbl_businessowner(business_name,business_id,business_desc) values(?,?,?,?)";
    //form data
    $conn->prepare($query)->execute([$req->business_name,$req->business_id,$req->business_desc]);
    $inserted_id = $conn->lastInsertId();
    echo json_encode($inserted_id);
    } catch(PDOException $error){
        $row["status"] = $error->getCode();
        $row["message"] = $error->getMessage();
        echo json_encode($row);
    }

?>