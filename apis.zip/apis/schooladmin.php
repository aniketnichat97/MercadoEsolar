<?php 
//product php code

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");

include 'DbConnect.php';
$httpPost = file_get_contents("php://input");
$req = json_decode($httpPost);



//loading product data

try{
    $model = new DbConnect();
    $conn = $model->getConnection();

    //insert product
    $query = "insert into tbl_schoooladmin(schooladmin_id,schooladmin_name,school_email,password) values(?,?,?,?)";
    //form data
    $conn->prepare($query)->execute([$req->schooladmin_id,$req->schooladmin_name,$req->school_email,$req->password]);
    $inserted_id = $conn->lastInsertId();
    echo json_encode($inserted_id);
    } catch(PDOException $error){
        $row["status"] = $error->getCode();
        $row["message"] = $error->getMessage();
        echo json_encode($row);
    }

?>