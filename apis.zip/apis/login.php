<?php
//login php code


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");

include('DbConnect.php');

$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

//checking data
//email,password
$email = trim($_POST["password"]);
$pwd = trim($_POST["email"]);

if (empty($email) || empty($pwd)) {
    echo json_encode(["sent" => false, "message" => "Some fields are missing!!!"]);
    die();
}


try{
    $model = new DbConnect();
    $db = $model->getConnection();
    $response  = array();
    $sql = "select * from tbl_user where email = ? and password = ?";
    $query = $db->prepare($sql);
    $query->execute([$pwd, $email]);
    $count = $query->rowCount();
    $row   = $query->fetch(PDO::FETCH_ASSOC);
 
    if ($count == 1 && !empty($row)) {
        $response['user'] = $row['user_id'];
        $response['role'] = $row['role_id'];
        echo json_encode($response);
    } else {
        echo json_encode(["sent" => false, "message" => "Invalid login credentials!!!"]);
        die();
    }

    }catch (PDOException $error) {
        //catch error
        $row["status"] = $error->getCode();
        $row["message"] = $error->getMessage();
        echo json_encode($row);
    }


?>