<?php 
include('DbConnect.php');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");
$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);


try{
    $model = new DbConnect();
    $conn = $model->getConnection();
    $query = "insert into tbl_user(user_name, dob, email, password, address, role_id, contact,gender)
    values(?,?,?,?,?,?,?,?)";
    $conn->prepare($query)->execute([$_POST['user_name'],$_POST['dob'],$_POST['email'],$_POST['password'],$_POST['address'],$_POST['role'],$_POST['contact'],$_POST['gender']]);
    $inserted_id = $conn->lastInsertId();
    echo json_encode($inserted_id);
}catch(PDOException $error){
    $row["status"] = $error->getCode();
    $row["message"] = $error->getMessage();
    echo json_encode($row);
}

?>