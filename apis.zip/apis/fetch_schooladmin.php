<?php
include('DbConnect.php');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

try{
    $model = new DbConnect();
    $db = $model->getConnection();
    $count = $db->query("select count(*) from tbl_schoooladmin")->fetchColumn();
    if($count >= 1) {
        $sql = "SELECT * FROM tbl_schoooladmin";
        $query = $db->prepare($sql);
		$query->execute();
		$row = $query->fetchAll(PDO::FETCH_ASSOC);
		echo json_encode($row);
    } else
    echo json_encode(array());

}catch(PDOException $error){
//catch error
$row["status"] = $error->getCode();
$row["message"] = $error->getMessage();
echo json_encode($row);
}

?>