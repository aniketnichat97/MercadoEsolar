<?php 
//product php code

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");

include 'DbConnect.php';
$httpPost = file_get_contents("php://input");
$req = json_decode($httpPost);



//loading adv data

try{
    $model = new DbConnect();
    $conn = $model->getConnection();

    //insert adv
    $query = "insert into tbl_advertisement(adv_title,adv_description) values(?,?)";
    //form data
    $conn->prepare($query)->execute([$req->adv_title,$req->adv_desc]);
    $inserted_id = $conn->lastInsertId();
    echo json_encode($inserted_id);
    } catch(PDOException $error){
        $row["status"] = $error->getCode();
        $row["message"] = $error->getMessage();
        echo json_encode($row);
    }

?>