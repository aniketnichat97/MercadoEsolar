<?php

include('DbConnect.php');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");
$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

try{
    $model - new DbConnect();
    $db = $model->getConnection();
    $sql = "DELETE FROM `tbl_user` WHERE user_id = ?";
    $query = $db->prepare($sql)->execute([$_POST['user_id']]);

} catch (PDOException $error) {
	//catch error
	$row["status"] = $error->getCode();
	$row["message"] = $error->getMessage();
	echo json_encode($row);
}
?>